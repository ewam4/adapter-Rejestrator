﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter2
{
    public class OldLoggingLibrary : ILogging
    {
        public void LogMessage(string message)
        {
            Console.WriteLine("Old Logging: " + message);
        }
    }
}
