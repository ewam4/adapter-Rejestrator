﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter2
{
    public class NewLoggingLibrary
    {
        public void RecordMessage(string message)
        {
            Console.WriteLine("New Logging: " + message);
        }
    }

}
