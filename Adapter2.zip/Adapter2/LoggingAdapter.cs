﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter2
{
    public class LoggingAdapter : ILogging
    {
        private readonly NewLoggingLibrary _newLoggingLibrary;

        public LoggingAdapter(NewLoggingLibrary newLoggingLibrary)
        {
            _newLoggingLibrary = newLoggingLibrary;
        }

        public void LogMessage(string message)
        {
            _newLoggingLibrary.RecordMessage(message);
        }
    }
}
