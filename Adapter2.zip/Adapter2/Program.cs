﻿
namespace Adapter2 {
    class Program
    {

        public static void Main(string[] args)
        {
            NewLoggingLibrary newLogging = new NewLoggingLibrary();
            ILogging logger = new LoggingAdapter(newLogging);

            logger.LogMessage("Test message");
        }
    }
}